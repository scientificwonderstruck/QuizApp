package com.example.panwangliang.apcomputersciencequiz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Jason Pan on 11/23/2017.
 */

public class DBHelper extends SQLiteOpenHelper{
    // Database Name
    private static final String DATABASE_NAME = "CompSciQuiz";
    // tasks table name
    private static final String TABLE_QUEST = "Questions";
    // tasks Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_QUES = "question";
    private static final String KEY_ANSWER = "answer";
    private static final String KEY_OPTA= "opta";
    private static final String KEY_OPTB= "optb";
    private static final String KEY_OPTC= "optc";
    private static final String KEY_OPTD= "optd";
    private static final String KEY_OPTE= "opte";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUEST);
        String sql = "CREATE TABLE IF NOT EXISTS " + TABLE_QUEST + " ( "
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_QUES
                + " TEXT, " + KEY_ANSWER+ " TEXT, "+KEY_OPTA +" TEXT, "
                +KEY_OPTB +" TEXT, "+KEY_OPTC+" TEXT, "+KEY_OPTD+" TEXT, "+KEY_OPTE+" TEXT)";
        db.execSQL(sql);


    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUEST);
        // Create tables again
        onCreate(db);
    }
    // Adding new question
    public void addQuestion(Question quest) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_QUES, quest.getQUESTION());
        values.put(KEY_ANSWER, quest.getANSWER());
        values.put(KEY_OPTA, quest.getCHOICEA());
        values.put(KEY_OPTB, quest.getCHOICEB());
        values.put(KEY_OPTC, quest.getCHOICEC());
        values.put(KEY_OPTD, quest.getCHOICED());
        values.put(KEY_OPTE, quest.getCHOICEE());
        // Inserting Row
        db.insert(TABLE_QUEST, null, values);
    }
    public List<Question> getAllQuestions() {
        SQLiteDatabase db=this.getReadableDatabase();

        List<Question> quesList = new ArrayList<Question>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_QUEST;
        Cursor cursor = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        while (cursor.moveToNext()) {
            Question quest = new Question();
            quest.setID(cursor.getInt(0));
            quest.setQUESTION(cursor.getString(1));
            quest.setANSWER(cursor.getString(2));
            quest.setCHOICEA(cursor.getString(3));
            quest.setCHOICEB(cursor.getString(4));
            quest.setCHOICEC(cursor.getString(5));
            quest.setCHOICED(cursor.getString(6));
            quest.setCHOICEE(cursor.getString(7));
            quesList.add(quest);
            }
        // return quest list
        return quesList;
    }



}





