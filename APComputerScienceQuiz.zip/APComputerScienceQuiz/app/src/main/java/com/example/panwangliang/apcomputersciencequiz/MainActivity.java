package com.example.panwangliang.apcomputersciencequiz;

import android.app.Activity;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends Activity {
    private DBHelper db;
    private TextView questionview;
    private RadioButton A;
    private RadioButton B;
    private RadioButton C;
    private RadioButton D;
    private RadioButton E;
    private List<Question> questList;
    private Button next;
    private Button arraystart;
    private Button stringstart;
    private Button recursionstart;
    private int questionnumber;
    private String type;
    private int count;
    private TextView ending;
    private TextView intro;
    private Button exit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DBHelper(this);
        initialize();
        questList = db.getAllQuestions();
        if(questList.size() ==0) {
            addQuestions();
            questList = db.getAllQuestions();
        }



    }
    public void firstArrayQuestion(View view){
        questionnumber = 0;
        setViews(questionnumber);
        questionview.setVisibility(View.VISIBLE);
        A.setVisibility(View.VISIBLE);
        B.setVisibility(View.VISIBLE);
        C.setVisibility(View.VISIBLE);
        D.setVisibility(View.VISIBLE);
        E.setVisibility(View.VISIBLE);
        arraystart.setVisibility(View.INVISIBLE);
        stringstart.setVisibility(View.INVISIBLE);
        recursionstart.setVisibility(View.INVISIBLE);
        intro.setVisibility(View.INVISIBLE);
        next.setVisibility(View.VISIBLE);
        type = "Arrays";

    }

    public void firstStringQuestion(View view){
        questionnumber = 10;
        setViews(questionnumber);
        questionview.setVisibility(View.VISIBLE);
        A.setVisibility(View.VISIBLE);
        B.setVisibility(View.VISIBLE);
        C.setVisibility(View.VISIBLE);
        D.setVisibility(View.VISIBLE);
        E.setVisibility(View.VISIBLE);
        arraystart.setVisibility(View.INVISIBLE);
        stringstart.setVisibility(View.INVISIBLE);
        recursionstart.setVisibility(View.INVISIBLE);
        intro.setVisibility(View.INVISIBLE);
        next.setVisibility(View.VISIBLE);
        type = "Strings";

    }
    public void firstRecursionQuestion(View view){
        questionnumber = 20;
        setViews(questionnumber);
        questionview.setVisibility(View.VISIBLE);
        A.setVisibility(View.VISIBLE);
        B.setVisibility(View.VISIBLE);
        C.setVisibility(View.VISIBLE);
        D.setVisibility(View.VISIBLE);
        E.setVisibility(View.VISIBLE);
        arraystart.setVisibility(View.INVISIBLE);
        stringstart.setVisibility(View.INVISIBLE);
        recursionstart.setVisibility(View.INVISIBLE);
        intro.setVisibility(View.INVISIBLE);
        next.setVisibility(View.VISIBLE);
        type = "Recursion";

    }


    public void nextQuestion(View view){
        if (type.equals("Arrays")) {

            if (questionnumber < 10) {
                String userchoice = "";
                if (A.isChecked()) userchoice = A.getText().toString();
                if (B.isChecked()) userchoice = B.getText().toString();
                if (C.isChecked()) userchoice = C.getText().toString();
                if (D.isChecked()) userchoice = D.getText().toString();
                if (E.isChecked()) userchoice = E.getText().toString();
                if (userchoice.equals(questList.get(questionnumber).getANSWER())) count++;
            }
            questionnumber++;
            if(questionnumber<10) setViews(questionnumber);


            if (questionnumber == 10) {
                String userchoice = "";
                if (A.isChecked()) userchoice = A.getText().toString();
                if (B.isChecked()) userchoice = B.getText().toString();
                if (C.isChecked()) userchoice = C.getText().toString();
                if (D.isChecked()) userchoice = D.getText().toString();
                if (E.isChecked()) userchoice = E.getText().toString();
                if (userchoice.equals(questList.get(9).getANSWER())) count++;
                questionview.setVisibility(View.INVISIBLE);
                A.setVisibility(View.INVISIBLE);
                B.setVisibility(View.INVISIBLE);

                C.setVisibility(View.INVISIBLE);
                D.setVisibility(View.INVISIBLE);
                E.setVisibility(View.INVISIBLE);
                next.setVisibility(View.INVISIBLE);
                ending.setVisibility(View.VISIBLE);
                ending.setText("Thanks for taking the quiz!\n"+ "Your score: "+count + "/10");
                exit.setVisibility(View.VISIBLE);
            }
            A.setChecked(false);
            B.setChecked(false);
            C.setChecked(false);
            D.setChecked(false);
            E.setChecked(false);


        }
        if (type.equals("Strings")) {
            if (questionnumber < 20) {
                String userchoice = "";
                if (A.isChecked()) userchoice = A.getText().toString();
                if (B.isChecked()) userchoice = B.getText().toString();
                if (C.isChecked()) userchoice = C.getText().toString();
                if (D.isChecked()) userchoice = D.getText().toString();
                if (E.isChecked()) userchoice = E.getText().toString();
                if (userchoice.equals(questList.get(questionnumber).getANSWER())) count++;
            }
            questionnumber++;
            if (questionnumber<20) setViews(questionnumber);


            if (questionnumber == 20) {
                String userchoice = "";
                if (A.isChecked()) userchoice = A.getText().toString();
                if (B.isChecked()) userchoice = B.getText().toString();
                if (C.isChecked()) userchoice = C.getText().toString();
                if (D.isChecked()) userchoice = D.getText().toString();
                if (E.isChecked()) userchoice = E.getText().toString();
                if (userchoice.equals(questList.get(19).getANSWER())) count++;
                questionview.setVisibility(View.INVISIBLE);
                A.setVisibility(View.INVISIBLE);
                B.setVisibility(View.INVISIBLE);
                C.setVisibility(View.INVISIBLE);
                D.setVisibility(View.INVISIBLE);
                E.setVisibility(View.INVISIBLE);
                next.setVisibility(View.INVISIBLE);
                ending.setVisibility(View.VISIBLE);
                ending.setText("Thanks for taking the quiz!\n"+ "Your score: "+count + "/10");
                exit.setVisibility(View.VISIBLE);

            }
            A.setChecked(false);
            B.setChecked(false);
            C.setChecked(false);
            D.setChecked(false);
            E.setChecked(false);


        }
        if (type.equals("Recursion")) {

            if (questionnumber < 30) {
                String userchoice = "";
                if (A.isChecked()) userchoice = A.getText().toString();
                if (B.isChecked()) userchoice = B.getText().toString();
                if (C.isChecked()) userchoice = C.getText().toString();
                if (D.isChecked()) userchoice = D.getText().toString();
                if (E.isChecked()) userchoice = E.getText().toString();
                if (userchoice.equals(questList.get(questionnumber).getANSWER())) count++;

            }
            questionnumber++;
            if(questionnumber<30) setViews(questionnumber);


            if (questionnumber == 30) {
                String userchoice = "";
                if (A.isChecked()) userchoice = A.getText().toString();
                if (B.isChecked()) userchoice = B.getText().toString();
                if (C.isChecked()) userchoice = C.getText().toString();
                if (D.isChecked()) userchoice = D.getText().toString();
                if (E.isChecked()) userchoice = E.getText().toString();
                if (userchoice.equals(questList.get(29).getANSWER())) count++;
                questionview.setVisibility(View.INVISIBLE);
                A.setVisibility(View.INVISIBLE);
                B.setVisibility(View.INVISIBLE);
                C.setVisibility(View.INVISIBLE);
                D.setVisibility(View.INVISIBLE);
                E.setVisibility(View.INVISIBLE);
                next.setVisibility(View.INVISIBLE);
                ending.setVisibility(View.VISIBLE);
                ending.setText("Thanks for taking the quiz!\n"+ "Your score: "+count + "/10");
                exit.setVisibility(View.VISIBLE);

            }
            A.setChecked(false);
            B.setChecked(false);
            C.setChecked(false);
            D.setChecked(false);
            E.setChecked(false);


        }


    }
    public void exitapp(View view){
        finish();

    }
    public void onRadioButtonClicked(View view){
        A.setChecked(false);
        B.setChecked(false);
        C.setChecked(false);
        D.setChecked(false);
        E.setChecked(false);
        ((RadioButton) view).setChecked(true);

    }

    public void setViews(int i){
        questionview.setText(questList.get(i).getQUESTION());
        A.setText(questList.get(i).getCHOICEA());
        B.setText(questList.get(i).getCHOICEB());
        C.setText(questList.get(i).getCHOICEC());
        D.setText(questList.get(i).getCHOICED());
        E.setText(questList.get(i).getCHOICEE());

    }
    public void addQuestions(){
        Question Q1 = new Question("fun is defined as follows: \npublic int fun(int[] v)\n   {\n     v[0]--;\n     return v[0] + 2;\n   }\nWhat is the value of v[0] after the following code segment is executed?\nint[] v = {3, 4, 5};\n     v[0] = fun(v);",  "a. 1","b. 2","c. 3","d. 4","e. 5","d. 4");
        db.addQuestion(Q1);
        Question Q2 = new Question("Given \n" +
                "     int[] a = {1, 3, 5, 7, 9, 11, 13}; \n" +
                " what are the values in a after disarray(a, 7) is called?  The method disarray is defined as follows: \n" +
                "   public void disarray(int[] a, int n)\n   {\n     if (n > 1)\n     {\n       disarray(a, n-1);\n       a[n-1] += a[n-2];\n     }\n   } ","a. 1, 4, 9, 16, 25, 36, 49 ","b. 1, 4, 8, 12, 16, 20, 24  ","c. 1, 8, 12, 16, 20, 24, 13  ","d. 1, 24, 20, 16, 12, 8, 4  ","e. None of the above  ","a. 1, 4, 9, 16, 25, 36, 49 ");
        db.addQuestion(Q2);
        Question Q3 = new Question(" Person[] players = {new SoccerPlayer(\"Mia Hamm\", 6),\n                         new SoccerPlayer(\"Kristine Lilly\", 5)};\n     System.out.println(players[0].compareTo(\n                            (SoccerPlayer)players[1])); // Line ***\n" +
                "     int[] x = {21, 22, 23}, y = new int[3];\n     divide5(x, y, y);","a. Syntax error in the class Person: other.name is not accessible ","b. Syntax error in the class SoccerPlayer: compareTo is redefined "
                ,"c. ClassCastException on Line *** ","d. Compiles and runs with no errors; displays 1","e. Compiles and runs with no errors; displays 2","e. Compiles and runs with no errors; displays 2");
        db.addQuestion(Q3);
        Question Q4 = new Question("int[] nums = {3, 0, 4, 2, 1};\n     int len = nums.length;\n     for (int i = 0; i < len; i++)\n       for (int count = 1; count <= len; count++)\n         nums[i] = nums[nums[i]];","a. 0, 0, 0, 0, 0  ","b. 0, 1, 2, 3, 4 ","c. 0, 0, 4, 2, 0 ","d. 0, 4, 2, 1, 3 ","e. 3, 0, 4, 2, 1  ","a. 0, 0, 0, 0, 0  ");
        db.addQuestion(Q4);
        Question Q5 = new Question("LinkedList<String> lst = new LinkedList<String>();\n     lst.add(\"X\");\n     lst.add(\"Y\");\n     lst.add(\"Z\");\n     Iterator<String> it = lst.iterator();\n     while(it.hasNext())\n       it.remove();\n     System.out.println(lst); ","a. []","b. [X]","c. [X, Z]","d. [X, Y, Z]","e. IllegalStateException","e. IllegalStateException");
        db.addQuestion(Q5);
        Question Q6 = new Question(" private boolean isSomething(int[] a, int n)\n   {\n     return n <= 2 ||\n       ((a[n-1] + a[n-3] == 2 * a[n-2]) && isSomething(a, n-1));\n   }\n For which of the following arrays isSomething(arr, arr.length) returns false?  ","a. int[] arr = {0}; ","b. int[] arr = {1, 2}; ","c. (C) int[] arr = {0, 3, 6}; ","d. (D) int[] arr = {1, 2, 4, 8}; ","e. (E) int[] arr = {1, 2, 3, 4, 5}; "," (D) int[] arr = {1, 2, 4, 8}; ");
        db.addQuestion(Q6);
        Question Q7 = new Question("int[][] m = new int[10][10];\n     String s = \"20012002\"; \n" +
                "     fun(m, s);\n     int sum = 0;\n     for (int k = 0; k < 10; k++)\n       sum += m[k][k];\n     System.out.println(sum);","a. 1","b. 2","c. 4","d. 7","e. 8","b. 2");
        db.addQuestion(Q7);
        Question Q8 = new Question("public int[] modify (int[] a)\n   {\n     a = new int[a.length];\n     for (int x : a)\n       x++;\n     return a;\n   } \n" +
                " what is the output from the following code segment? \n" +
                "     int[] arr = {1, 2, 3};\n     arr = modify(arr);\n     System.out.println(Arrays.toString(arr)); ","a. [0, 0, 0] ","b. [1, 1, 1] ","c. [1, 2, 3]","d. [2, 3, 4] ","e. Unpredictable list of three int values ","\"a. [0, 0, 0] \"");
        db.addQuestion(Q8);
        Question Q9 = new Question("Consider the following method: \n" +
                "   public void divide5(int[] a, int[] q, int[] r)\n   {\n     q[0] = a[0] / 5;\n     r[0] = a[0] % 5;\n   } \n" +
                " What is the value of y[0] after the following statements are executed? \n" +
                "     int[] x = {21, 22, 23}, y = new int[3];\n     divide5(x, y, y); ","a. 0","b. 1","c. 2","d. 4","e. 21","b. 1");
        db.addQuestion(Q9);
        Question Q10 = new Question("What are the values in arr after the following statements are executed? \n" +
                "     int arr[] = {1, 1, 0, 0, 0}; \n" +
                "     for (int i = 2; i < arr.length; i++)\n       arr[i] += arr[i-1] + arr[i-2]; ","a. 1 1 0 1 1","b. 1 1 2 1 0 ","c. 1 1 2 2 2","d. 1 1 2 3 5 ","e. 1 1 2 4 8 ","d. 1 1 2 3 5 ");
        db.addQuestion(Q10);
        Question Q11= new Question("What is the output of the following code segment?\n" +
                "\tString str1 = “Happy ”;\n" +
                "\tString str2 = str1;\n" +
                "\tstr2 += “New Year! ”;\n" +
                "\tstr2.substring(6);\n" +
                "\tSystem.out.println(str1 + str2);\n","a. Happy New Year!","b. Happy Happy New Year!","c. Happy New Year! New Year!","d. Happy New Year! Happy New Year!","e. Happy New Year! Happy","b. Happy Happy New Year!");
        db.addQuestion(Q11);
        Question Q12 = new Question("Consider the method \n" +
                "\" +\n" +
                "                \"   public String mystery(String s)\\n   {\\n     String s1 = s.substring(0, 1);\\n     String s2 = s.substring(1, s.length() - 1);\\n     String s3 = s.substring(s.length() - 1);\\n     if (s.length() <= 3)\\n       return s3 + s2 + s1;\\n     else\\n       return s1 + mystery(s2) + s3;\\n   } \\n\" +\n" +
                "                \" What is the output of \\n\" +\n" +
                "                \"     System.out.println(mystery(\"DELIVER\")); ","a. DELIVER ","b. DEVILER ","c. REVILED ","d. RELIVED ","e. DLEIEVR ","b. DEVILER ");
        db.addQuestion(Q12);
        Question Q13= new Question("Which of the following expressions will evaluate to true when x and y are Boolean variables with different values?\n" +
                "\n" +
                "I.\t(x || y) && (!x || !y)\n" +
                "II.\t(x || y) && !(x && y)\n" +
                "III.\t(x && !y) || (!x && y)\n","a. I only","b. II only","c. I and II","d. II and III","e. I, II and III","e. I, II and III");
        db.addQuestion(Q13);
        Question Q14= new Question("String key = \"\";\n     Map<String, String> map = new TreeMap<String, String>();\n     for (int k = 0; k < 3; k++)\n     {\n       key += k;\n       String value = \"A\";\n       map.put(key, value);\n       value += \"B\";\n       map.put(key, value);\n     }\n     System.out.println(map.size());\n ","a. 1","b. 2","c. 3","d. 4","e. 6","c. 3");
        db.addQuestion(Q14);
        Question Q15= new Question(" public String packed(String msg)\n   {\n     String packedMsg = \"\"; \n" +
                "     for (int i = 0; i < msg.length(); i++)\n     {\n       if (msg.charAt(i) != '.')\n       {\n         int len = packedMsg.length();\n         if (len == 0 || msg.charAt(i) != packedMsg.charAt(len-1))\n           packedMsg += msg.substring(i, i+1);\n       }\n     }\n     return packedMsg;\n   } ","a. xxo..ooo..xx..x ","b. ..xxooooooxxxx.. ","c. xxooooxxx ","d. xxooooooxxox","e. xox ","d. xxooooooxxox");
        db.addQuestion(Q15);
        Question Q16= new Question("Given \n" +
                "     String a = \"a\", b = \"b\", zero = \"\";\n      Integer c = new Integer(0); \n" +
                " what is the output of \n" +
                "     System.out.println(       ((a+b)+c).equals(a+(b+c)) + \" \"\n +       (c + zero).equals(zero + c) + \" \"\n +       (a + null).equals(a + \"null\")); \n" +
                " ","a. false false false ","b. false true true","c. true false true ","d. true true false ","e. true true true \n","d. true true false ");
        db.addQuestion(Q16);
        Question Q17= new Question("String mixup(String word)\n   {\n     if (word.length() == 1)\n       return \"\";\n     else\n       return mixup(word.substring(0, word.length() - 1))\n                                 + word.charAt(word.length() - 2);   } ","a. IDEAL","b. IDEA ","c. LEAD","d. LEDA","e. DEAL ","b. IDEA ");
        db.addQuestion(Q17);
        Question Q18= new Question("Given \n" +
                "     String s = \"SOLD\"; \n" +
                " which of the following calls does NOT return 1? ","a. s.lastIndexOf(\"OLD\"); ","b. s.lastIndexOf(\"OLD\", 0); ","c. s.lastIndexOf(\"OLD\", 1);","d. s.lastIndexOf(\"OLD\", 2); ","e. s.lastIndexOf(\"OLD\", 3); \n","b. s.lastIndexOf(\"OLD\", 0); ");
        db.addQuestion(Q18);
        Question Q19= new Question("StringBuffer s = new StringBuffer(\"WYOMING\");\n     int n = s.length();\n        for (int k = 0; k < 3; k++)\n     {\n       char temp = s.charAt(n-1);\n       for (int i = k+1; i < n; i++)\n         s.setCharAt(i, s.charAt(i-1));\n       s.setCharAt(k, temp);\n     }\n     System.out.println(s); ","a. YOMINGW ","b. MINGWYO","c. GWWWWWW ","d. MINGOYW ","e. GNIMOYW","c. GWWWWWW ");
        db.addQuestion(Q19);
        Question Q20= new Question("Which of the following statements DOES NOT print 2006?","a. System.out.println(\"200\" + 6);","b. System.out.println(200 + \"6\"); ","c. System.out.println((int)(2006 * 1.0000002)); ","d. System.out.println(2006 * 2000000 / 2000000);","e. System.out.println(2006 / 1000 * 1000 + 2006 % 1000);","d. System.out.println(2006 * 2000000 / 2000000);");
        db.addQuestion(Q20);
        Question Q21 = new Question("public static int Mystery(int a) {\n" +
                "\tif (a <= 1)\n" +
                "\t\treturn 1;\n" +
                "\telse {\n" +
                "\t\tif (a % 2 == 0)\n" +
                "\t\t\treturn a – Mystery(a – 1);\n" +
                "\t\telse\n" +
                "return a + Mystery(a – 1);\n" +
                "}\n" +
                "}\n","a. 0","b. 1","c. 4","d. 8","e. 10","d. 8");
        db.addQuestion(Q21);
        Question Q22 = new Question("Consider the following method:\n" +
                "\n" +
                "public static int recurFriday(int x, int y) {\n" +
                "\tif (x < = y)\n" +
                "\t\treturn x;\n" +
                "\telse\n" +
                "\t\treturn recurFriday( x – 1, y + 1);\n" +
                "}\n" +
                "\n" +
                "What value is returned as a result of the call recurFriday(7,  2)?\n","a. 0","b. 1","c. 4","d. 6","e. 8","c. 4");
        db.addQuestion(Q22);
        Question Q23 = new Question("The method pow is defined as follows:\n" +
                "\n" +
                "  public double pow(double x, int n)\n" +
                "  {\n" +
                "    if (n == 0)\n" +
                "      return 1.0;\n" +
                "    \n" +
                "   double y = pow(x, n/2);          // Line 1\n" +
                "   y *= y;                          // Line 2\n" +
                "   \n" +
                "   if (n % 2 != 0)\n" +
                "      y *= x;\n" +
                "   \n" +
                "   return y;\n" +
                "  }\n+(a)\tIf we called pow(2, 15), how many times in total, including the original call, would pow be called?","a. 2","b. 5","c. 7","d. 15","e. None of the Above","b. 5");
        db.addQuestion(Q23);

        Question Q24 = new Question("The method pow is defined as follows:\n" +
                "\n" +
                "  public double pow(double x, int n)\n" +
                "  {\n" +
                "    if (n == 0)\n" +
                "      return 1.0;\n" +
                "    \n" +
                "   double y = pow(x, n/2);          // Line 1\n" +
                "   y *= y;                          // Line 2\n" +
                "   \n" +
                "   if (n % 2 != 0)\n" +
                "      y *= x;\n" +
                "   \n" +
                "   return y;\n" +
                "  }\n"+"\tSuppose we replaced Line 1 and Line 2 above with one statement\n" +
                "\n" +
                "    double y = pow(x, n/2) * pow(x, n/2);\n" +
                "\n" +
                "If we called pow(2, 15), how many times would pow be called in this version?\n","a. 3","b. 9","c. 15","d. 31","e. None of the Above","d. 31");
        db.addQuestion(Q24);

        Question Q25 = new Question("public String prepare(String s) \n" +
                "{ \n" +
                "int k = s.length() / 2; \n" +
                "if (k <= 1) \n" +
                "return s; \n" +
                "return s.charAt(k - 1) + \n" +
                "prepare(s.substring(0, k - 1) + \n" +
                "s.substring(k + 1, 2*k)) + \n" +
                "s.charAt(k); \n" +
                "} \n" +
                "what does prepare(\"LEMONADE\") return? \n","a. ONMAEDLE ","b. OLEMADEN ","c. OMELEDAN ","d. OOOONNNN ","e. LEMONADE","c. OMELEDAN ");
        db.addQuestion(Q25);

        Question Q26 = new Question("What is the output of the following code? \n" +
                "String barb = \"BARBARA\"; \n" +
                "scramble(barb); \n" +
                "System.out.println(barb); \n" +
                "\n" +
                "The method scramble is defined as follows: \n" +
                "public String scramble(String str) { \n" +
                "if (str.length() >= 2) \n" +
                "{ \n" +
                "int n = str.length() / 2; \n" +
                "str = scramble(str.substring(n)) + str.substring(0, n); \n" +
                "} \n" +
                "return str; \n" +
                "} \n","a. BARBARA ","b. ARBABAR ","c. AABAR ","d. ARBABARB ","e. ARABARBARB","a. BARBARA ");
        db.addQuestion(Q26);

        Question Q27 = new Question("Which of the following best describes the base case(s) in the following recursive method?\n" +
                "\n" +
                "  public int factorial(int n) {\n" +
                "    int product = 1;\n" +
                "    if (n > 1)\n" +
                "      product = n * factorial(n-1);\n" +
                "    return product;\n" +
                "  }\n","a. The method does not have a base case","b. n > 0","c. n > 1 ","d. n ≤ 1 ","e. n ≤ 0","d. n ≤ 1 ");
        db.addQuestion(Q27);
        Question Q28 = new Question("Suppose the method isSuch is defined as follows: \n" +
                "\n" +
                "public static boolean isSuch(int n) { \n" +
                "return n > 2 && !isSuch(n - 2); \n" +
                "} \n" +
                "\n" +
                "What is the output from \n" +
                "System.out.println(isSuch(99) + \" \" + isSuch(100)); \n","a. false false","b. false true","c. true false","d. true true","e. StackOverflowError exception","d. true true");
        db.addQuestion(Q28);
        Question Q29 = new Question("Suppose sum(v, n) returns the sum of the first n elements in v.  The mystery method is defined as follows:\n" +
                "\n" +
                "  public double mystery(double[] v, int n){\n" +
                "    if (n == 0)\n" +
                "      return 0;\n" +
                "    return mystery(v, n-1) + sum(v, n-1) * v[n-1];\n" +
                "  }\n" +
                "\n" +
                "Given\n" +
                "\n" +
                "    double[] v = {-2, -1, 0, 1, 2};\n" +
                "\n" +
                "what value is returned when mystery(v, v.length) is called?  \n","a. -5","b. -3","c. 0","d. 2","e. 5","a. -5");
        db.addQuestion(Q29);
        Question Q30 = new Question("A recursive method upNdown is defined as follows: \n" +
                "\n" +
                "public void upNdown(int n) { \n" +
                "if (n > 1) { \n" +
                "if (n % 2 != 0) \n" +
                "upNdown(n+1); \n" +
                "else \n" +
                "upNdown(n/2); \n" +
                "System.out.print(\"*\"); \n" +
                "} \n" +
                "} \n" +
                "\n" +
                "How many stars are displayed when upNdown(5) is called? \n","a. 1","b. 2","c. 3","d. 4","e. 5","e. 5");
        db.addQuestion(Q30);



    }


    public void initialize(){
        questionview =  findViewById(R.id.Question);
        A = findViewById(R.id.A);
        B = findViewById(R.id.B);
        C = findViewById(R.id.C);
        D = findViewById(R.id.D);
        E = findViewById(R.id.E);
        next = findViewById(R.id.next);
        arraystart = findViewById(R.id.arraystart);
        ending = (TextView) findViewById(R.id.end);
        stringstart= findViewById(R.id.stringstart);
        recursionstart=findViewById(R.id.recursionstart);
        intro = findViewById(R.id.introduction);
        exit = findViewById(R.id.exit);

    }



}
