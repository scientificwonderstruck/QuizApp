package com.example.panwangliang.apcomputersciencequiz;

/**
 * Created by Jason Pan on 11/23/2017.
 */

public class Question {

        private int ID;
        private String QUESTION;
        private String CHOICEA;
        private String CHOICEB;
        private String CHOICEC;
        private String CHOICED;
        private String CHOICEE;
        private String ANSWER;


        public Question(){
            ID = 0;
            QUESTION = "";
            CHOICEA = "";
            CHOICEB = "";
            CHOICEC = "";
            CHOICED = "";
            CHOICEE = "";
            ANSWER = "";
        }

        public Question(String Q, String A, String B, String C, String D, String E, String Ans){
            QUESTION = Q;
            CHOICEA = A;
            CHOICEB = B;
            CHOICEC = C;
            CHOICED = D;
            CHOICEE = E;
            ANSWER = Ans;
        }

        public int getID(){
            return ID;
        }
        public String getQUESTION(){
            return QUESTION;
        }
        public String getCHOICEA(){
            return CHOICEA;
        }
        public String getCHOICEB(){
            return CHOICEB;
        }
        public String getCHOICEC(){
            return CHOICEC;
        }
        public String getCHOICED(){
            return CHOICED;
        }
        public String getCHOICEE(){
            return CHOICEE;
        }
        public String getANSWER(){
            return ANSWER;
        }
        public void setID(int id){
            ID = id;
        }
        public void setQUESTION(String quest){
            QUESTION = quest;
        }
        public void setCHOICEA(String A){
            CHOICEA = A;
        }
        public void setCHOICEB(String B){
            CHOICEB = B;
        }
        public void setCHOICEC(String C){
            CHOICEC = C;
        }
        public void setCHOICED(String D){
            CHOICED = D;
        }
        public void setCHOICEE(String E){
            CHOICEE = E;
        }
        public void setANSWER(String ans){
            ANSWER = ans;
        }
}
